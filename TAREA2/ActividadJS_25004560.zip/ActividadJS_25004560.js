alert ("PROGRAMA PARA SABER SU SIGNO ZODIACAL") 

var mes_naci = prompt("indique mes de nacimiento")
var dia_naci = prompt("indique su dia de nacimiento")


if (mes_naci == 11 && dia_naci >= 23 && dia_naci <= 30) {
    alert("SAGITARIO");
  
} else if (mes_naci == 12 && dia_naci >= 1 && dia_naci <= 21) {
    alert("SAGITARIO");
}

if (mes_naci == 10 && dia_naci >= 24 && dia_naci <= 31) {
    alert("ESCORPIO");
  
} else if (mes_naci == 11 && dia_naci >= 1 && dia_naci <= 22) {
    alert("ESCORPIO");
}

if (mes_naci == 9 && dia_naci >= 23 && dia_naci <= 30) {
    alert("LIBRA");
  
} else if (mes_naci == 10 && dia_naci >= 1 && dia_naci <= 23) {
    alert("LIBRA");
}

if (mes_naci == 8 && dia_naci >= 24 && dia_naci <= 30) {
    alert("VIRGO");
  
} else if (mes_naci == 9 && dia_naci >= 1 && dia_naci <= 22) {
    alert("VIRGO");
}

if (mes_naci == 7 && dia_naci >= 23 && dia_naci <= 31) {
    alert("LEO");
  
} else if (mes_naci == 8 && dia_naci >= 1 && dia_naci <= 22) {
    alert("LEO");
}

if (mes_naci == 6 && dia_naci >= 21 && dia_naci <= 30) {
    alert("CANCER");
  
} else if (mes_naci == 7 && dia_naci >= 1 && dia_naci <= 22) {
    alert("CANCER");
}

if (mes_naci == 5 && dia_naci >= 21 && dia_naci <= 31) {
    alert("GEMINIS");
  
} else if (mes_naci == 6 && dia_naci >= 1 && dia_naci <= 20) {
    alert("GEMINIS");
}

if (mes_naci == 4 && dia_naci >= 21 && dia_naci <= 30) {
    alert("TAURO");
  
} else if (mes_naci == 5 && dia_naci >= 1 && dia_naci <= 20) {
    alert("TAURO");
}

if (mes_naci == 3 && dia_naci >= 21 && dia_naci <= 31) {
    alert("ARIES");
  
} else if (mes_naci == 4 && dia_naci >= 1 && dia_naci <= 20) {
    alert("ARIES");
}

if (mes_naci == 12 && dia_naci >= 22 && dia_naci <= 31) {
    alert("CAPRICORNIO");
  
} else if (mes_naci == 1 && dia_naci >= 1 && dia_naci <= 20) {
    alert("CAPRICORNIO");
}

if (mes_naci == 1 && dia_naci >= 21 && dia_naci <= 31) {
    alert("ACUARIO");
  
} else if (mes_naci == 2 && dia_naci >= 1 && dia_naci <= 19) {
    alert("ACUARIO");
}

if (mes_naci == 2 && dia_naci >= 21 && dia_naci <= 29) {
    alert("PISCIS");
  
} else if (mes_naci == 3 && dia_naci >= 1 && dia_naci <= 20) {
    alert("PISCIS");
}